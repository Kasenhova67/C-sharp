﻿using SQLite;

namespace Lab_1_4.Entities;

[Table("Categories")]
public class Category
{
    [PrimaryKey, AutoIncrement, Indexed]
    public int Id { get; set; }

    public string Name { get; set; }

    public string Description { get; set; }

}