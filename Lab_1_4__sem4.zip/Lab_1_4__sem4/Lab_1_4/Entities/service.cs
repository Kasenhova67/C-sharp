﻿using SQLite;

namespace Lab_1_4.Entities;

[Table("Services")]
public class Service
{
    [PrimaryKey, AutoIncrement, Indexed]
    public int Id { get; set; }
    public string Name { get; set; }
    public double Rating { get; set; }
    [Indexed]
    public int CategoryId { get; set; }
}