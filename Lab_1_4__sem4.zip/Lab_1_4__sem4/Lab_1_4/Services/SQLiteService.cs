﻿using Lab_1_4.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LoremNET;
using SQLite;

namespace Lab_1_4.Services;

class SQLiteService : IDbService
{
    private SQLiteConnection db;
    public SQLiteService()
    {
        string dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "database.db");
        db = new SQLiteConnection(dbPath);
        db.CreateTable<Category>();
        db.CreateTable<Service>();
    }
    public IEnumerable<Category> GetAllCategories()
    {
        return db.Table<Category>().ToList();
    }
    public IEnumerable<Service> GetCategoryServices(int id) //один ко многим
    {
        return db.Table<Service>().Where(t => t.CategoryId == id).ToList();
    }
    public void Init()
    {

        List<Category> categories = new List<Category>
            {
                 new Category { Id = 1, Name = "Luxury" },
                 new Category { Id = 2, Name = "Standard" },
                 new Category { Id = 3, Name = "Economy" }

        };
        db.DeleteAll<Category>();
        db.DeleteAll<Service>();
        db.InsertAll(categories);

        List<Service> servicies = new List<Service>();


        int amount = categories.Count * Random.Shared.Next(5, 10 * categories.Count - 4);
        for (int i = 0; i < amount; i++)
        {
            servicies.Add(new Service { Name = Lorem.Words(1), Rating = Lorem.Number(0, 5) + 0.25 * Lorem.Number(0, 4) });
        }

        //Distribute
        int ind = 0, add = 5;
        foreach (Service attraction in servicies)
        {
            attraction.CategoryId = categories[ind].Id;
            add--;

            if (add == 0)
            {
                ind = (ind + 1) % 3;
                add = 5;
            }
        }

        db.InsertAll(servicies);
    }

}
