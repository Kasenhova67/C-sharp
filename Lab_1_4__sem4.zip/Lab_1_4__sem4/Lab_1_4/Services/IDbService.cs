﻿using Lab_1_4.Entities;

namespace Lab_1_4.Services;

public interface IDbService
{
    
        IEnumerable<Category> GetAllCategories();
        IEnumerable<Service> GetCategoryServices(int id);
        void Init();
    
}