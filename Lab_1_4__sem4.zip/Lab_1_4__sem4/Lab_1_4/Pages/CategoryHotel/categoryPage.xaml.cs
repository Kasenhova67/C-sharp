﻿using System.Collections.ObjectModel;
using Lab_1_4.Entities;
using Lab_1_4.Services;

namespace Lab_1_4.Pages.CategoryHotel;

public partial class CategoryPage : ContentPage
{
    private IDbService _dbService;

    public CategoryPage(IDbService dbService)
    {
        InitializeComponent();
        _dbService = dbService;
        _dbService.Init();

        categoryPicker.ItemsSource = new ObservableCollection<Category>(_dbService.GetAllCategories());
    }

    private void OnCategorySelected(object sender, EventArgs e)
    {
        if (categoryPicker.SelectedItem is Category selectedCategory)
        {
            if (categoryPicker.SelectedItem is Category selectedRoute)

                serviceView.ItemsSource = _dbService.GetCategoryServices(selectedCategory.Id);
        }
    }
}