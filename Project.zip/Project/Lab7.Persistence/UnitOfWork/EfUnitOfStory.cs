﻿namespace Lab7.Persistence.UnitOfWork;
using Data;
using Repository;
using Lab7.Domain.Abstractions;
public class EfUnitOfWork : IUnitOfWork
{
    private readonly AppDbContext _context;
    private readonly Lazy<IRepository<Blogger>> _bloggerRepository;
    private readonly Lazy<IRepository<Story>> _storyRepository;

    public EfUnitOfWork(AppDbContext context)
    {
        _context = context;
        _bloggerRepository = new Lazy<IRepository<Blogger>>(() =>
            new EfRepository<Blogger>(context));
        _storyRepository = new Lazy<IRepository<Story>>(() =>
            new EfRepository<Story>(context));
    }

    public IRepository<Blogger> BloggerRepository => _bloggerRepository.Value;
    public IRepository<Story> StoryRepository => _storyRepository.Value;

    public async Task CreateDatabaseAsync() => await _context.Database.EnsureCreatedAsync();
    public async Task RemoveDatabaseAsync() => await _context.Database.EnsureDeletedAsync();
    public async Task SaveAllAsync() => await _context.SaveChangesAsync();
}
