﻿global using Lab7.Domain.Entities;
global using Lab7.Domain.Abstractions;
