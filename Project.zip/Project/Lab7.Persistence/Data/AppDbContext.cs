﻿namespace Lab7.Persistence.Data;
using Microsoft.EntityFrameworkCore;

public class AppDbContext : DbContext
{
    public DbSet<Blogger> Bloggers { get; set; }
    public DbSet<Story> Stories { get; set; }

    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
       
    }

}
