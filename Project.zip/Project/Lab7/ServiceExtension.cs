﻿using Lab7.Application.StoryUseCases;
using Lab7.UI.Pages;
using Lab7.UI.ViewModels;
namespace Lab7.UI;
public static class ServiceExtension
{
    public static IServiceCollection RegisterPages(this IServiceCollection services)
    {
        services
            .AddTransient<BloggerPage>()
            .AddTransient<StoryDetailsPage>()
            .AddTransient<AddOrUpdateStoryPage>()
            .AddTransient<AddOrUpdateBloggerPage>();
        ;
        return services;
    }

    public static IServiceCollection RegisterViewModels(this IServiceCollection services)
    {
        services
            .AddTransient<BloggersViewModel>()
            .AddTransient<StoryDetailsViewModel>()
            .AddTransient<AddOrUpdateStoryViewModel>()
            .AddTransient<AddOrUpdateBloggerViewModel>()
            .AddSingleton<DbInitializer>(); // Add this line

        return services;
    }
    public static IServiceCollection CreateImageFolders(this IServiceCollection services)
    {
        string imagesDir =System.IO.Path.Combine(FileSystem.AppDataDirectory, "Images") ;
        string storyImagesDir = Path.Combine(FileSystem.AppDataDirectory, "Images", "Stories");
        string bloggerImagesDir = Path.Combine(FileSystem.AppDataDirectory, "Images", "Bloggers");
        System.IO.Directory.CreateDirectory(imagesDir);
        System.IO.Directory.CreateDirectory(storyImagesDir);
        System.IO.Directory.CreateDirectory(bloggerImagesDir);
        return services;
    }
}