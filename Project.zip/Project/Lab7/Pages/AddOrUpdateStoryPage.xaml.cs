﻿using Lab7.UI.ViewModels;
namespace Lab7.UI.Pages;
public partial class AddOrUpdateStoryPage : ContentPage
{
    public AddOrUpdateStoryPage(AddOrUpdateStoryViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}