﻿using Lab7.UI.ViewModels;
namespace Lab7.UI.Pages;
public partial class AddOrUpdateBloggerPage : ContentPage
{
    public AddOrUpdateBloggerPage(AddOrUpdateBloggerViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}