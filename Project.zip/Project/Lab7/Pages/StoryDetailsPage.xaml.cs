﻿using Lab7.UI.ViewModels;
namespace Lab7.UI.Pages;
public partial class StoryDetailsPage : ContentPage
{
    public StoryDetailsPage(StoryDetailsViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}