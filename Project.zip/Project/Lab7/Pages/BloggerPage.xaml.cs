﻿using Lab7.UI.ViewModels;
using System.Diagnostics;
namespace Lab7.UI.Pages;

public partial class BloggerPage : ContentPage
{
        public BloggerPage(BloggersViewModel viewModel)
        {
            try
            {
                InitializeComponent();
                BindingContext = viewModel;

                // Load data when page appears
                this.Appearing += async (s, e) =>
                {
                    try
                    {
                        await viewModel.UpdateBloggersListCommand.ExecuteAsync(null);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"Error loading data: {ex}");
                    }
                };
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Page initialization failed: {ex}");
                throw;
            }
        }
    
}