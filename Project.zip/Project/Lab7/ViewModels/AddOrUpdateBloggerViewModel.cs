﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Lab7.Application.BloggerUseCases.Commands;
using MediatR;

namespace Lab7.UI.ViewModels;

public partial class AddOrUpdateBloggerViewModel : ObservableObject, IQueryAttributable
{
    private readonly IMediator _mediator;

    public AddOrUpdateBloggerViewModel(IMediator mediator)
    {
        _mediator = mediator;
    }

    [ObservableProperty]
    private IAddOrUpdateBloggerRequest request;

    [ObservableProperty]
    private FileResult image;

    [RelayCommand]
    public async Task PickImage()
    {
        var customFileType = new FilePickerFileType(
            new Dictionary<DevicePlatform, IEnumerable<string>>
            {
                { DevicePlatform.WinUI, new[] { ".png" } },
            });

        PickOptions options = new()
        {
            PickerTitle = "Please select a PNG image",
            FileTypes = customFileType,
        };

        try
        {
            var result = await FilePicker.Default.PickAsync(options);
            if (result != null && result.FileName.EndsWith(".png", StringComparison.OrdinalIgnoreCase))
            {
                Image = result;
            }
        }
        catch (Exception ex)
        {
            return;
        }
    }

    [RelayCommand]
    async Task AddOrUpdateBlogger()
    {
        try
        {
            if (Request?.Blogger?.Name == null || Request.Blogger.Name == string.Empty ||
                Request.Blogger.Bio == null || Request.Blogger.Bio == string.Empty)
            {
                ErrText = "Error: Name and Bio are required.";
                return;
            }

            await _mediator.Send(Request);

            if (Image != null)
            {
                await SaveImageToFile(Image, Request.Blogger.Id);
            }

            await Shell.Current.GoToAsync("..");
        }
        catch (Exception ex)
        {
            ErrText = $"Error saving blogger: {ex.Message}";
        }
    }

    private async Task SaveImageToFile(FileResult image, int bloggerId)
    {
        try
        {
            string directoryPath = Path.Combine(FileSystem.AppDataDirectory, "Images", "Bloggers");
            Directory.CreateDirectory(directoryPath);
            string filename = Path.Combine(directoryPath, $"{bloggerId}.png");

            using var stream = await image.OpenReadAsync();
            using var fileStream = File.Create(filename);
            await stream.CopyToAsync(fileStream);
        }
        catch (Exception ex)
        {
            ErrText = $"Error saving image: {ex.Message}";
        }
    }

    [ObservableProperty]
    private string errText;

    public void ApplyQueryAttributes(IDictionary<string, object> query)
    {
        Request = query["Request"] as IAddOrUpdateBloggerRequest;
    }
}