﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Lab7.Application.BloggerUseCases.Commands;
using Lab7.Application.BloggerUseCases.Queries;
using Lab7.Application.StoryUseCases.Commands;
using Lab7.Application.StoryUseCases.Queries;
using Lab7.UI.Pages;
using Lab7.Domain.Entities;
using MediatR;
using System.Collections.ObjectModel;

namespace Lab7.UI.ViewModels;

public partial class BloggersViewModel : ObservableObject
{
    private readonly IMediator _mediator;
    public BloggersViewModel(IMediator mediator)
    {
        _mediator = mediator;
    }

    public ObservableCollection<Blogger> Bloggers { get; set; } = new();
    public ObservableCollection<Story> Stories { get; set; } = new();

    [ObservableProperty] Blogger selectedBlogger = new();
    [ObservableProperty] Story selectedStory = new();
    [ObservableProperty] int storiesCount;
    [ObservableProperty] string errorText;

 

    [RelayCommand]
    async Task UpdateStoriesList() => await GetStories();

    [RelayCommand]
    async Task ShowDetails(Story story) => await GotoDetailsPage(story);

    private async Task GotoDetailsPage(Story story)
    {
        IDictionary<string, Object> parameters =
            new Dictionary<string, Object>()
            {
                { "Story", story }
            };
        await Shell.Current.GoToAsync(nameof(StoryDetailsPage), parameters);
    }

    [RelayCommand]
    async Task UpdateBloggersList()
    {
        try
        {
            var bloggers = await _mediator.Send(new GetBloggersQuery());
            await MainThread.InvokeOnMainThreadAsync(() =>
            {
                Bloggers.Clear();
                foreach (var blogger in bloggers ?? Enumerable.Empty<Blogger>())
                {
                    Bloggers.Add(blogger);
                }
            });
        }
        catch (Exception ex)
        {
            ErrorText = $"Error loading bloggers: {ex.Message}";
            
        }
    }

    [RelayCommand]
    private async Task AddBlogger()
    {
        await GotoAddOrUpdatePage(nameof(AddOrUpdateBloggerPage),
            new AddBloggerCommand() { Blogger = new Blogger() });
    }

    [RelayCommand]
    private async Task UpdateBlogger()
    {
        if (SelectedBlogger is null)
            return;
        await GotoAddOrUpdatePage(nameof(AddOrUpdateBloggerPage),
            new UpdateBloggerCommand() { Blogger = SelectedBlogger });
    }

    [RelayCommand]
    private async Task AddStory()
    {
        if (SelectedBlogger is null)
            return;
        await GotoAddOrUpdatePage(nameof(AddOrUpdateStoryPage),
            new AddStoryCommand() { Story = new Story() });
    }

    private async Task GotoAddOrUpdatePage(string route, IRequest request)
    {
        IDictionary<string, object> parameters =
            new Dictionary<string, object>()
            {
                { "Request", request },
                { "Blogger", SelectedBlogger }
            };
        await Shell.Current.GoToAsync(route, parameters);
    }

    [RelayCommand]
    private async Task DeleteBlogger()
    {
        if (selectedBlogger is null)
            return;
        await DeleteBloggerAction();
    }

    private async Task DeleteBloggerAction()
    {
        await _mediator.Send(new DeleteBloggerCommand(SelectedBlogger));
        await GetBloggers();
    }

    public async Task GetBloggers()
    {
        var bloggers = await _mediator.Send(new GetBloggersQuery());
        await MainThread.InvokeOnMainThreadAsync(() =>
        {
            Bloggers.Clear();
            foreach (var blogger in bloggers)
            {
                Bloggers.Add(blogger);
            }
        });
    }

    public async Task GetStories()
    {
        if (SelectedBlogger is null)
        {
            Stories.Clear();
            return;
        }
        var stories = await _mediator.Send(new GetStoriesByBloggerIdQuery(SelectedBlogger.Id));
        await MainThread.InvokeOnMainThreadAsync(() =>
        {
            Stories.Clear();
            foreach (var story in stories)
                Stories.Add(story);
            StoriesCount = Stories.Count;
        });
    }
}
