﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Lab7.Application.StoryUseCases.Commands;
using Lab7.Application.StoryUseCases.Queries;
using Lab7.Domain.Entities;
using Lab7.UI.Pages;
using MediatR;
namespace Lab7.UI.ViewModels;

[QueryProperty("Story", "Story")]
public partial class StoryDetailsViewModel : ObservableObject
{
    private readonly IMediator _mediator;
    public StoryDetailsViewModel(IMediator mediator)
    {
        _mediator = mediator;
    }

    [ObservableProperty]
    Story story;

    [ObservableProperty]
    string storyTitle;

    [ObservableProperty]
    int storyLikes;

    [ObservableProperty]
    string storyContent;

    [ObservableProperty]
    string storyBloggerName;

    [ObservableProperty]
    int storyId;

    [RelayCommand]
    async void GetStoryById()
    {
        Story = await _mediator.Send(new GetStoryByIdQuery(Story.Id));
        if (Story is null)
            return;
        StoryTitle = Story.Title;
        StoryContent = Story.Content;
        StoryBloggerName = Story.Blogger.Name;
        StoryLikes = Story.Likes;
        StoryId = Story.Id;
    }

    [RelayCommand]
    async Task UpdateStory() =>
        await GotoAddOrUpdatePage<AddOrUpdateStoryPage>(new UpdateStoryCommand() { Story = Story });

    private async Task GotoAddOrUpdatePage<Page>(IAddOrUpdateStoryRequest request)
        where Page : ContentPage
    {
        IDictionary<string, object> parameters =
            new Dictionary<string, object>()
            {
                { "Request", request },
                {"Blogger", request.Story.Blogger!}
            };
        await Shell.Current.GoToAsync(nameof(AddOrUpdateStoryPage), parameters);
    }

    [RelayCommand]
    async Task DeleteStory() =>
        await RemoveStory(Story);

    private async Task RemoveStory(Story story)
    {
        await _mediator.Send(new DeleteStoryCommand(story));
        await Shell.Current.GoToAsync("..");
    }
}
