﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Lab7.Application.BloggerUseCases.Queries;
using Lab7.Application.StoryUseCases.Commands;
using Lab7.Domain.Entities;
using MediatR;
using System.Collections.ObjectModel;
namespace Lab7.UI.ViewModels;
public partial class AddOrUpdateStoryViewModel : ObservableObject, IQueryAttributable
{
    private readonly IMediator _mediator;
    public AddOrUpdateStoryViewModel(IMediator mediator)
    {
        _mediator = mediator;
    }

    [ObservableProperty]
    string errText;

    Blogger _blogger;
    [ObservableProperty]
    Blogger blogger = new();

    [ObservableProperty]
    FileResult image;

    [ObservableProperty]
    IAddOrUpdateStoryRequest request;

    public ObservableCollection<Blogger> Bloggers { get; set; } = new();

    [RelayCommand]
    public async void PickImage()
    {
        PickOptions options = new()
        {
            PickerTitle = "Please select a png image",
            FileTypes = FilePickerFileType.Images
        };
        try
        {
            var result = await FilePicker.Default.PickAsync(options);
            if (result != null)
            {
                Image = result;
            }
        }
        catch (Exception ex)
        {
            return;
        }
        return;
    }

    [RelayCommand]
    async Task AddOrUpdateStory()
    {
        await Task.Delay(1);
        if (Request.Story.Title is null || Request.Story.Title == string.Empty ||
            Request.Story.Content is null || Request.Story.Content == string.Empty)
        {
            return;
        }
        Request.Story.Blogger = Blogger;
        await _mediator.Send(Request);

        if (Image != null)
        {
            using var stream = await Image.OpenReadAsync();
            string filename = Path.Combine(FileSystem.AppDataDirectory,
                "Images", "Stories", $"{Request.Story.Id}.png");

            using var fileStream = File.Create(filename);
            stream.Seek(0, SeekOrigin.Begin);
            stream.CopyTo(fileStream);
            stream.Seek(0, SeekOrigin.Begin);
        }
        await Shell.Current.GoToAsync("..");
    }

    [RelayCommand]
    async Task UpdateBloggersList() => await GetBloggers();

    public async Task GetBloggers()
    {
        var bloggers = await _mediator.Send(new GetBloggersQuery());
        await MainThread.InvokeOnMainThreadAsync(() =>
        {
            Bloggers.Clear();
            foreach (var blogger in bloggers)
                Bloggers.Add(blogger);
        });
        Blogger = _blogger;
    }

    public void ApplyQueryAttributes(IDictionary<string, object> query)
    {
        Request = query["Request"] as IAddOrUpdateStoryRequest;
        _blogger = query["Blogger"] as Blogger;
    }
}