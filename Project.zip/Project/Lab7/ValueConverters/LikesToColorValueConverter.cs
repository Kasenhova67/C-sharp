using System.Globalization;
namespace Lab7.UI.ValueConverters;
internal class LikesToColorValueConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if ((int)value < 100)
            return Colors.LightPink;
        if ((int)value < 500)
            return Colors.LightGreen;
        if ((int)value < 10000)
            return Colors.LightBlue;
        if ((int)value < 500000)
            return Colors.Lavender;
        return Colors.Gold;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        throw new NotImplementedException();
    }
}