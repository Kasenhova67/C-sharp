﻿using Lab7.Domain.Abstractions;

namespace Lab7
{
    public partial class App : Microsoft.Maui.Controls.Application
    {
        private readonly IServiceProvider _serviceProvider;

        public App(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
            InitializeComponent();
            MainPage = new AppShell();
        }

        protected override void OnSleep()
        {
            // Called when app goes to background
            using var scope = _serviceProvider.CreateScope();
            var unitOfWork = scope.ServiceProvider.GetRequiredService<IUnitOfWork>();
            unitOfWork.SaveAllAsync().Wait();
            base.OnSleep();
        }

        protected override void OnResume()
        {
            // Called when app comes back to foreground
            base.OnResume();
        }
    }
}
