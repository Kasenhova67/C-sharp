﻿using CommunityToolkit.Maui;
using Lab7.Application;
using Lab7.Application.StoryUseCases;
using Lab7.Persistence;
using Lab7.Persistence.Data;
using Lab7.UI;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Diagnostics;  // Add this for Debug

namespace Lab7
{
    public static class MauiProgram
    {
        // В MauiProgram.cs
        public static async Task<MauiApp> CreateMauiApp()
        {
            var dbPath = Path.Combine(FileSystem.AppDataDirectory, "blogger.db");
            Debug.WriteLine($"Database path: {dbPath}");
            var connStr = $"Data Source={dbPath}";

            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .UseMauiCommunityToolkit()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });

            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseSqlite(connStr)
                .Options;

            builder.Services
                .AddApplication()
                .AddPersistence(options)
                .RegisterPages()
                .RegisterViewModels()
                .CreateImageFolders();

            var app = builder.Build();

            // Убедитесь, что база данных создана (без удаления существующей)
            using var scope = app.Services.CreateScope();
            var dbContext = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            await dbContext.Database.EnsureCreatedAsync();

            // Инициализируем данные только если база пустая
            try
            {
                var dbInitializer = scope.ServiceProvider.GetRequiredService<DbInitializer>();
                await dbInitializer.Initialize();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Database initialization failed: {ex}");
            }

            return app;
        }
    }
}

