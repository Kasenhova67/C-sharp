﻿using Lab7.UI.Pages;

namespace Lab7
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
            Routing.RegisterRoute(nameof(AddOrUpdateBloggerPage), typeof(AddOrUpdateBloggerPage));
            Routing.RegisterRoute(nameof(AddOrUpdateStoryPage), typeof(AddOrUpdateStoryPage));
            Routing.RegisterRoute(nameof(StoryDetailsPage), typeof(StoryDetailsPage));
        }
    }
}