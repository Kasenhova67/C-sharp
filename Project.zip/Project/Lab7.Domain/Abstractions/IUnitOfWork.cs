﻿namespace Lab7.Domain.Abstractions;

using Lab7.Domain.Entities;

public interface IUnitOfWork
{
    IRepository<Blogger> BloggerRepository { get; }
    IRepository<Story> StoryRepository { get; }
    public Task RemoveDatabaseAsync();
    public Task CreateDatabaseAsync();
    public Task SaveAllAsync();
}