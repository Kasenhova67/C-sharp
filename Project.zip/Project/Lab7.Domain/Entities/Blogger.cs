﻿namespace Lab7.Domain.Entities;

public class Blogger : Entity
{
    public string Name { get; set; }
    public string Bio { get; set; }
    public ICollection<Story> Stories { get; set; } = new List<Story>();
}
