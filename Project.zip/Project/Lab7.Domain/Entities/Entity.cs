﻿namespace Lab7.Domain.Entities
{
    public class Entity
    {
        public int Id { get; set; }
    }
}
