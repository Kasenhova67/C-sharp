﻿using Lab7.Domain.Entities;

namespace Lab7.Domain.Entities;
public class Story : Entity
{
    public string Title { get; set; }
    public string Content { get; set; }
    public int Likes { get; set; }
    public Blogger Blogger { get; set; }
    public int BloggerId { get; set; }
}