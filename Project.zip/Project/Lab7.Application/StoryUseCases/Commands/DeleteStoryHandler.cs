﻿namespace Lab7.Application.StoryUseCases.Commands;
internal class DeleteStoryHandler(IUnitOfWork unitOfWork) :
    IRequestHandler<DeleteStoryCommand>
{
    public async Task Handle(DeleteStoryCommand request, CancellationToken cancellationToken)
    {
        await unitOfWork.StoryRepository.DeleteAsync(request.Story, cancellationToken);
        await unitOfWork.SaveAllAsync();
    }
}