﻿namespace Lab7.Application.StoryUseCases.Commands;
public interface IAddOrUpdateStoryRequest : IRequest
{
    Story Story { get; set; }
}
