﻿namespace Lab7.Application.StoryUseCases.Commands;
internal class AddStoryHandler(IUnitOfWork unitOfWork) :
    IRequestHandler<AddStoryCommand>
{
    public async Task Handle(AddStoryCommand request, CancellationToken cancellationToken)
    {
        await unitOfWork.StoryRepository.AddAsync(request.Story, cancellationToken);
        await unitOfWork.SaveAllAsync();
    }

}