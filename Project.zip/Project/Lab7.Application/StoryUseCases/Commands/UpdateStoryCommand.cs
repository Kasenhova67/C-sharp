﻿namespace Lab7.Application.StoryUseCases.Commands;
public sealed class UpdateStoryCommand : IAddOrUpdateStoryRequest
{
    public Story Story { get; set; }
}