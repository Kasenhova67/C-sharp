﻿namespace Lab7.Application.StoryUseCases.Commands;
public sealed record DeleteStoryCommand(Story Story) : IRequest { }