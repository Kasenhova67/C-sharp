﻿namespace Lab7.Application.StoryUseCases.Commands;
internal class UpdateStoryHandler(IUnitOfWork unitOfWork) :
    IRequestHandler<UpdateStoryCommand>
{
    public async Task Handle(UpdateStoryCommand request, CancellationToken cancellationToken)
    {
        await unitOfWork.StoryRepository.UpdateAsync(request.Story, cancellationToken);
        await unitOfWork.SaveAllAsync();
    }
}