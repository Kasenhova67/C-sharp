﻿namespace Lab7.Application.StoryUseCases.Queries;
public sealed record GetStoriesByBloggerIdQuery(int Id) : IRequest<IEnumerable<Story>> { }