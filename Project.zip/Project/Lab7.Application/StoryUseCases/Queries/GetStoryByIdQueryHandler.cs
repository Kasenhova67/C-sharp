﻿namespace Lab7.Application.StoryUseCases.Queries;
internal class GetStoryByIdQueryHandler(IUnitOfWork unitOfWork) :
    IRequestHandler<GetStoryByIdQuery, Story>
{
    public async Task<Story> Handle(GetStoryByIdQuery request,
        CancellationToken cancellationToken)
    {
        return await unitOfWork
            .StoryRepository
            .FirstOrDefaultAsync(s => s.Id == request.Id, cancellationToken);
    }
}