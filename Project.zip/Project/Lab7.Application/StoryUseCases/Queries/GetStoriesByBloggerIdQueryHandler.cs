﻿
namespace Lab7.Application.StoryUseCases.Queries;
internal class GetStoriesByBloggerIdQueryHandler(IUnitOfWork unitOfWork) :
    IRequestHandler<GetStoriesByBloggerIdQuery, IEnumerable<Story>>
{
    public async Task<IEnumerable<Story>> Handle(GetStoriesByBloggerIdQuery request,
        CancellationToken cancellationToken)
    {
        return await unitOfWork
            .StoryRepository
            .ListAsync(s => s.BloggerId.Equals(request.Id), cancellationToken);
    }
}