﻿namespace Lab7.Application.StoryUseCases.Queries;
public sealed record GetStoryByIdQuery(int Id) : IRequest<Story> { }