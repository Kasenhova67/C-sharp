﻿namespace Lab7.Application.StoryUseCases;
using LoremNET;
using Microsoft.Extensions.DependencyInjection;

public class DbInitializer  
{
    private readonly IUnitOfWork _unitOfWork;

    public DbInitializer(IUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async Task Initialize()
    {
        var existingBloggers = await _unitOfWork.BloggerRepository.ListAllAsync();
        if (existingBloggers.Any())
        {
            return; // База уже заполнена, выходим
        }

        IReadOnlyList<Blogger> bloggers = new List<Blogger>()
    {
        new (){
            Name = "Mary Vain",
            Bio = "Путешественница, делится впечатлениями о разных странах"
        },
        new (){
            Name = "Fooddy",
            Bio = "Шеф-повар с 10-летним опытом, автор кулинарных книг"
        },
        new (){
            Name = "Arnold",
            Bio = "лайфстайл"
        }
    };

        foreach (var blogger in bloggers)
            await _unitOfWork.BloggerRepository.AddAsync(blogger);

        await _unitOfWork.SaveAllAsync();

  
        await AddStoriesForBlogger(bloggers[0], new List<Story>
    {
        new() {
            Title = "Мое путешествие в Японию",
            Content = "Весной 2023 я посетила Токио и Киото. Особенно впечатлили..." +
                     "1. Традиционные онсэны\n2. Чайные церемонии\n3. Сады камней",
            Likes = 12434
        },
         new() {
            Title = "Мое путешествие в Бора Бора",
            Content = "Весной 2024 я посетила Бора Бора.",
            Likes = 500000
        },
        new() {
            Title = "Как путешествовать бюджетно",
            Content = "10 советов для экономии в поездках:\n1. Бронируйте жилье заранее\n" +
                     "2. Используйте локальные сервисы\n3. Путешествуйте в межсезонье...",
            Likes = 876
        }
    });

      
        await AddStoriesForBlogger(bloggers[1], new List<Story>
    {
        new() {
            Title = "Borsch",
            Content = "Borsch is the famous soup in many Russian families, as well as many Eastern and Central European countries. The recipes of borsch vary, but vegetables (mainly beet) and sour cream are always the main ingredients. The beetroot used in cooking borsch gives the soup its trademark deep reddish-purple color.\r\n\r\nIngredients\r\n4 qt. water\r\n14 oz. beef stock\r\n1 small head of cabbage\r\n5 large potatoes\r\n1 large carrot\r\n1 med. beet root\r\n1 med. onion\r\n1 bay leaf\r\n2 tablespoons tomato paste\r\n3-5 cloves garlic\r\nverdure (parsley, dill, etc.)\r\nsour cream",
            Likes = 15420
        },
          new() {
            Title = "Pancakes",
            Content = "The ingredients needed to cook Pancakes:\r\nTake 1 1/2 cups flour\r\nPrepare 3 1/2 teaspoons baking powder\r\nPrepare 1 teaspoon salt\r\nPrepare 1 tablespoon white sugar\r\nUse 1 1/2 cups milk\r\nGet 1 egg\r\nYou need 3 tablespoons melted butter\r\nSteps to make Pancakes:\r\nIn a large bowl, sift together the flour, baking powder, salt and sugar. Make a well in the centre and pour in the milk, egg and melted butter, mix until smooth.\r\nHeat a lightly oiled griddle or frying pan over medium heat. Pour or scoop the batter onto the griddle, using approximately 1/4 cup for each pancake. Brown on both sides and serve hot!",
            Likes = 15420
        },
    });

        await AddStoriesForBlogger(bloggers[2], new List<Story>
    {
        new() {
            Title = "Новый питомец",
            Content = ".",
            Likes = 932
        },
        new() {
            Title = "Мой режим питания",
            Content = "Основные принципы:\n- 5 приемов пищи в день\n- Баланс белков/жиров/углеводов\n" +
                     "- 2 литра воды ежедневно\n- Минимум сахара...",
            Likes = 765
        }
    });

        await _unitOfWork.SaveAllAsync();
    }

    private async Task AddStoriesForBlogger(Blogger blogger, List<Story> stories)
    {
        foreach (var story in stories)
        {
            story.Blogger = blogger;
            await _unitOfWork.StoryRepository.AddAsync(story);
        }
    }
}