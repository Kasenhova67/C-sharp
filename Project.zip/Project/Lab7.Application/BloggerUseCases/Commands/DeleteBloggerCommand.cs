﻿namespace Lab7.Application.BloggerUseCases.Commands;
public sealed record DeleteBloggerCommand(Blogger Blogger) : IRequest { }
