﻿namespace Lab7.Application.BloggerUseCases.Commands;
public interface IAddOrUpdateBloggerRequest : IRequest
{
    Blogger Blogger { get; set; }
}