﻿namespace Lab7.Application.BloggerUseCases.Commands;
internal class DeleteBloggerHandler(IUnitOfWork unitOfWork) :
    IRequestHandler<DeleteBloggerCommand>
{
    public async Task Handle(DeleteBloggerCommand request, CancellationToken cancellationToken)
    {
        await unitOfWork.BloggerRepository.DeleteAsync(request.Blogger, cancellationToken);
        await unitOfWork.SaveAllAsync();
    }
}
