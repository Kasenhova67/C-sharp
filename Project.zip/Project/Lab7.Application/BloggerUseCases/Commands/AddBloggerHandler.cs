﻿namespace Lab7.Application.BloggerUseCases.Commands;
internal class AddBloggerHandler(IUnitOfWork unitOfWork) :
    IRequestHandler<AddBloggerCommand>
{
    public async Task Handle(AddBloggerCommand request, CancellationToken cancellationToken)
    {
        await unitOfWork.BloggerRepository.AddAsync(request.Blogger, cancellationToken);
        await unitOfWork.SaveAllAsync();
    }
}