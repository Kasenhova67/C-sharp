﻿namespace Lab7.Application.BloggerUseCases.Commands;
public sealed class AddBloggerCommand : IAddOrUpdateBloggerRequest
{
    public Blogger Blogger { get; set; }
}