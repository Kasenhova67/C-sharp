﻿namespace Lab7.Application.BloggerUseCases.Commands;
public sealed class UpdateBloggerCommand : IAddOrUpdateBloggerRequest
{
    public Blogger Blogger { get; set; }
}