﻿namespace Lab7.Application.BloggerUseCases.Commands;
internal class UpdateBloggerHandler(IUnitOfWork unitOfWork) :
    IRequestHandler<UpdateBloggerCommand>
{
    public async Task Handle(UpdateBloggerCommand request, CancellationToken cancellationToken)
    {
        await unitOfWork.BloggerRepository.UpdateAsync(request.Blogger, cancellationToken);
        await unitOfWork.SaveAllAsync();
    }
}