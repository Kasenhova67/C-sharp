﻿namespace Lab7.Application.BloggerUseCases.Queries;
internal class GetBloggersRequestHandler(IUnitOfWork unitOfWork) :
    IRequestHandler<GetBloggersQuery, IEnumerable<Blogger>>
{
    public async Task<IEnumerable<Blogger>> Handle(GetBloggersQuery request,
        CancellationToken cancellationToken)
    {
        return await unitOfWork.BloggerRepository.ListAllAsync(cancellationToken);
    }
}