﻿namespace Lab7.Application.BloggerUseCases.Queries;
public class GetBloggersQuery : IRequest<IEnumerable<Blogger>> { }
